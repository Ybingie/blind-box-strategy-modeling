# Report LaTeX Source

This package contains the source for my blind-draw collection modeling report, including its references, figures, and tables.

## Compile

Use `main.tex` as the main document and **XeLaTeX** as the compiler. References use biblatex with **Biber**. With a local LaTeX installation, run:

```bash
latexmk -xelatex main.tex
```

Alternatively, upload this ZIP as a separate Overleaf project, select `main.tex`, and choose XeLaTeX.

The figures are included, so the report can be compiled without running Python. The accompanying repository provides the Excel workbook and analysis scripts separately. New Python outputs do not automatically update the figures in this source package.
